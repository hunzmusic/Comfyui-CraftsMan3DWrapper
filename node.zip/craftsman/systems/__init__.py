from . import (
    shape_autoencoder,
    shape_diffusion,
    shape_rectified_flow
)